﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Wolf_Island.Extensions;

internal static class CollectionsExtension
{
    private static readonly Random Rnd = new Random();

    public static IEnumerable<T> GetShuffledCollections<T>(this IEnumerable<T> collection, out IEnumerable<T> outPut)
    {
        if (collection == null)
            throw new ArgumentNullException("The collection must not be NULL");

        T[] arrTemp = collection.ToArray();

        for (int i = collection.Count() - 1; i > 0; i--)
        {
            int j = Rnd.Next(i + 1);
            (arrTemp[i], arrTemp[j]) = (arrTemp[j], arrTemp[i]);
        }

        outPut = arrTemp;

        return arrTemp;
    }
    public static T[] GetShuffledCollections<T>(this IEnumerable<T> collection)
    {
        //ArgumentNullException.ThrowIfNull(collection);

        if (collection == null)
            throw new ArgumentNullException("The collection must not be NULL");

        T[] arrTemp = collection.ToArray();

        //Random.Shared.Shuffle(arrTemp);  // only with .NET 8+

        for (int i = collection.Count() - 1; i > 0; i--)
        {
            int j = Rnd.Next(i + 1);
            (arrTemp[i], arrTemp[j]) = (arrTemp[j], arrTemp[i]);
        }

        return arrTemp;
    }
}