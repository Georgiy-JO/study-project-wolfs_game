﻿using System;
using System.Collections.Generic;
using System.Text;
using Wolf_Island.Extensions;

namespace Wolf_Island.Entities.Objects.FoodKinds
{
    public class Grass : Grassy
    {
        public uint GrowthInterval { get; set; } = 20;

        public ushort SproutsPerGrowth { get; set; } = 1;

        private uint _growthTimer;

        public Grass() : base(2, (0, 0))
        {
            _growthTimer = GrowthInterval;
        }

        public Grass((uint x, uint y) coords, uint growthInterval = 20, ushort sprouts = 1) : base(2, (coords.x, coords.y))
        {
            GrowthInterval = growthInterval;
            SproutsPerGrowth = sprouts;
            _growthTimer = growthInterval;
        }

        public override void Update(Game.Data data, List<(uint x, uint y)>? newData)
        {
            if (newData == null)
                return;

            if (_growthTimer > 0)
            {
                _growthTimer--;

                return;
            }

            _growthTimer = GrowthInterval;

            Game.Direction[] possiblePlacing = { Game.Direction.dNorth, Game.Direction.dSouth, Game.Direction.dEast, Game.Direction.dWest };

            possiblePlacing = possiblePlacing.GetShuffledCollections();

            int placed = 0;
            foreach (var pp in possiblePlacing)
            {
                (long x, long y) coords = Game.GetCoords(pp, this.Coord);

                bool flag = true;

                if (coords.y < 0 || coords.x < 0 || coords.y >= data.Height || coords.x >= data.Width)
                    flag = false;

                for (int i = 0; flag && i < data.Animals.Count; i++)
                    if (coords == data.Animals[i].Coord) flag = false;

                for (int i = 0; flag && i < data.Food.Count; i++)
                    if (coords == data.Food[i].Coord) flag = false;

                if (flag)
                {
                    newData.Add(((uint)coords.x, (uint)coords.y));
                    placed++;
                }

                if (placed >= SproutsPerGrowth)
                    break;
            }
        }
    }

    public class Remains : Meaty
    {
        public Remains(uint fValue = 0) : base(fValue, (0, 0)) { }
        public Remains((uint x, uint y) coords, uint fValue = 0) : base(fValue, (coords.x, coords.y)) { }
    }
}