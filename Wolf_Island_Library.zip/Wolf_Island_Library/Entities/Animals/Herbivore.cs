using System;
using System.Collections.Generic;
using System.Text;
using Wolf_Island.Entities.Animals.Service;
using Wolf_Island.Entities.Objects;

namespace Wolf_Island.Entities.Animals
{
    public abstract class Herbivore : Animal
    {
        protected Herbivore(AnimalData dat, (uint x, uint y) coordinates) : base(dat, coordinates)
        { }

        public override bool Feed(Food food)
        {
            if (IsAlive && CanEat(food) && !IsFull)
            {
                _fullness = Math.Min(_fullness + food.Value, MaxFullness);
                return true;
            }
            return false;
        }

        public override bool Feed(Animal food) => false;

        public override bool CanEat(Food food)
        {
            //ArgumentNullException.ThrowIfNull(food);

            if (food == null)
                throw new ArgumentNullException("The food must not be NULL");

            return food is Grassy;
        }

        public override bool CanEat(Animal food) => false;
    }
}