﻿using System;
using System.Collections.Generic;
using System.Text;
using Wolf_Island.Entities.Animals;
using Wolf_Island.Entities.Animals.Service;

namespace Wolf_Island.Data
{
    public sealed class ConfigRegistry
    {
        private readonly Dictionary<string, IConfig> _byId = new();

        public static ConfigRegistry FromDtos<TDto, TConfig>(IEnumerable<TDto> dtos, Func<TDto, TConfig> createConfig) where TConfig : IConfig where TDto : IDto
        {
            var registry = new ConfigRegistry();

            foreach (var dto in dtos)
            {
                var config = createConfig(dto);
                if (string.IsNullOrWhiteSpace(dto.Id))
                    throw new InvalidDataException("Config has empty id");

                registry._byId[dto.Id] = config;
            }

            return registry;
        }

        public T Get<T>(string id) where T : IConfig
        {
            if (!_byId.TryGetValue(id, out var config))
                throw new KeyNotFoundException($"Animal config '{id}' not found");

            if (config is not T typedConfig)
                throw new InvalidCastException($"Config '{id}' имеет тип {config.GetType().Name}, но запрашивался тип {typeof(T).Name}. Проверьте соответствие ID и типа.");

            return typedConfig;
        }

        public bool TryGet<T>(string id, out T? config) where T : IConfig
        {
            config = default;

            if (!_byId.TryGetValue(id, out var value))
                return false;

            if (value is T typed)
            {
                config = typed;

                return true;
            }

            return false;
        }
    }
}